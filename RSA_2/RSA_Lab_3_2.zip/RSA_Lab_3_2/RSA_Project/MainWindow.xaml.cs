﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RSA_Project
{
    public partial class StartWindow : Window
    {
        private const byte lengthN = 26;//Длина ключа
        private static List<byte[]> partition;//Разбиение строки на байт массивы
        private RSACrypto RSA; // Класс шифровальщика с открытым ключом
        public StartWindow()
        {
            InitializeComponent();
            Update();
        }

        
        private void Update()
        {
            BigInteger p, q;
            BigInteger.TryParse("107714533189", out p);
            BigInteger.TryParse("33421167632320168879", out q);
            RSA = new RSACrypto(p, q);
            infoLabel.Text = String.Format("N:  {0} \n E: {1} \n D: {2}\n",
                RSA.N, RSA.PublicKey, RSA.PrivateKey);
        }

        private List<byte[]> EncryptMessage(List<byte[]> p)
        {//Зашифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(RSA.EncryptMessage(block));
            }
            return result;
        }
        private List<byte[]> DecryptMessage(List<byte[]> p)
        {//Разшифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(RSA.DecryptMessage(block));
            }
            return result;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            partition = EncryptMessage(PartitionManager.StringToPartition(inTextMessage.Text, RSA.NbyteLength-1));
            encryptedBox.Text = PartitionManager.PartitionToString(partition);
        }

        

        private void decryptBtn_Click(object sender, RoutedEventArgs e)
        {
  
            decryptedBox.Text = PartitionManager.PartitionToString(DecryptMessage(partition));
        }

        private void inTextMessage_TextChanged(object sender, TextChangedEventArgs e)
        {
            encryptedBox.Text = "";
            decryptedBox.Text = "";
        }
    }
}
