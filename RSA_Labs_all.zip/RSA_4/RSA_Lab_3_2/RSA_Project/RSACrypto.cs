﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Security.Cryptography;
using System.Diagnostics;

namespace RSA_Project
{   /*
     * Алгоритм шифрования с открытм ключом
     */
    public class RSACrypto
    {
        private int[] primeNumbers = new int[] {  17, 257, 65537 };//Простые числа для открытого ключа(взаимо простые с N)
        private BigInteger  n, p, q;//p,q,n
        private BigInteger d,//private key
            e;//public key

        public BigInteger N
        {
            get
            {
                return n;
            }
        }

        public BigInteger PrivateKey
        {
            get
            {
                return e;
            }
        }

        public BigInteger PublicKey
        {
            get
            {
                return d;
            }
        }


        public RSACrypto(BigInteger _p,BigInteger _q)
        {/*
          * _p,_q два простых числа которые инициализируют класс
          */
            this.p = _p;
            this.q = _q;
            this.n = p * q;//Вычисляем число n как произведение целых  чисел
            BigInteger eF = (p - 1) * (q - 1);//Считаем  функцию эйлера
            this.d = primeNumbers[new Random().Next(0,primeNumbers.Length)];//Находим взаимо-простое с ним
            this.e = generatePrivateKey(eF);
        }

        public byte[] EncryptMessage(byte[] message)
        {/*Шифруем сообщение открытым ключом
          * message - сообщение (в виде байт массива)
         */
            return BigInteger.ModPow(new BigInteger(message), d, n).ToByteArray();
        }

        public long NbyteLength
        {//Длина числа  байт-масссива числа n
            get
            {
                return n.ToByteArray().Length; 
            }
        }


        public byte[] DecryptMessage(byte[] message)
        {//Расшифруем cообщение открытм ключом
            return BigInteger.ModPow(new BigInteger(message), e, n).ToByteArray();
        }

        private BigInteger generatePrivateKey(BigInteger E)
        {//Вычисляем закрытый ключ, находя обратный по модулю элемент кольца
            BigInteger x,y;
            BigInteger g = NOD(d,E ,out x,out  y);
            return (x % E + E) % E;
        }


        
        private BigInteger NOD(BigInteger a, BigInteger b,out BigInteger x,out BigInteger y)
        {/*Расширеный Алгоритм Евклида
          * Решает диофантово уравнение
          * */
            if (a == 0)
            {
                x = 0;
                y = 1;
                return b;
            }
            BigInteger x1, y1;
            BigInteger d = NOD(b % a, a, out x1, out y1);
            x = y1 - (b / a) * x1;
            y = x1;
            return d;
        }


    }
}
