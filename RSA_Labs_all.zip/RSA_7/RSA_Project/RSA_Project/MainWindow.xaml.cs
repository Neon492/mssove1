﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RSA_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const byte lengthN = 28;//Длина ключа
        private static List<byte[]> partition;//Разбиение строки на байт массивы
        private RSA RSAcrypto; // Класс шифровальщика с открытым ключом
        public MainWindow()
        {
            InitializeComponent();
            //contentPanel.IsEnabled = false;
            RSAcrypto = new RSA(lengthN);
            UpdateRSAInfo();
        }

        
        private void UpdateRSAInfo()
        {
            infoRSALabel.Content = String.Format("P:  {0} \nQ:  {1} \nN:  {2} \nОткртый ключ: {3} \nЗакрытый ключ: {4}\n",
                RSAcrypto.primePair.Key, RSAcrypto.primePair.Value, RSAcrypto.Module, RSAcrypto.PublicKey, RSAcrypto.PrivateKey);
        }

        private List<byte[]> EncryptMessage(List<byte[]> p)
        {//Зашифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(RSAcrypto.Encrypt(block));
            }
            return result;
        }
        private List<byte[]> DecryptMessage(List<byte[]> p)
        {//Разшифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(RSAcrypto.Decrypt(block));
            }
            return result;
        }
        
        #region События формы
        private void encryptBtn_Click(object sender, RoutedEventArgs e)
        {
            partition = EncryptMessage(MessageManager.partitionOfString(messageBox.Text, RSAcrypto.ModuleLength-1));
            encryptedBox.Text = MessageManager.PartitionToString(partition);
        }

        

        private void decryptBtn_Click(object sender, RoutedEventArgs e)
        {
  
            decryptedBox.Text = MessageManager.PartitionToString(DecryptMessage(partition));
        }

        private void messageBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            encryptedBox.Text = "";
            decryptedBox.Text = "";
        }
        private void generateNewRSAButton_Click(object sender, RoutedEventArgs e)
        {
            RSAcrypto = new RSA(lengthN);
            UpdateRSAInfo();
            partition = new List<byte[]>();
            messageBox.Text = String.Empty;
            encryptedBox.Text = String.Empty;
            decryptedBox.Text = String.Empty;
        }

        #endregion

    }
}
