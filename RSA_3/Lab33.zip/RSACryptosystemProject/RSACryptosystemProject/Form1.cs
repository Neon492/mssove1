﻿using System;
using System.Numerics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSACryptosystemProject
{
    public partial class Form1 : Form
    {
        private static List<byte[]> partition;//Разбиение строки на байт массивы
        private Cryptosystem cry; // Класс шифровальщика с открытым ключом
        private BigInteger p, q;
        public Form1()
        {
            InitializeComponent();
            Refresh();
        }

        private List<byte[]> EncryptMessage(List<byte[]> p)
        {//Зашифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(cry.Encrypt(block));
            }
            return result;
        }
        private List<byte[]> DecryptMessage(List<byte[]> p)
        {//Разшифровать строку
            List<byte[]> result = new List<byte[]>();
            foreach (byte[] block in p)
            {
                result.Add(cry.Decrypt(block));
            }
            return result;
        }

        private void Refresh()
        {//Обновляем инофрмацию и объекты
            BigInteger.TryParse("522224862977635043", out p);
            BigInteger.TryParse("19847157582713581370902789", out q);
            cry = new Cryptosystem(p, q);
            infoBox.Text = String.Format("N:  {0} \r\nОткртый ключ: {1} \r\nЗакрытый ключ: {2}\n",
                cry.Module, cry.PublicKey, cry.PrivateKey);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            partition = EncryptMessage(StringConverter.StringToPartition(textBox1.Text, cry.ModuleLength - 1));
            textBox2.Text = StringConverter.PartitionToString(partition);
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
           textBox3.Text = StringConverter.PartitionToString(DecryptMessage(partition));
        }
    }
}
