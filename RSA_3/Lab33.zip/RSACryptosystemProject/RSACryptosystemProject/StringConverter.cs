﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSACryptosystemProject
{
    public static class StringConverter
    {


        public static String PartitionToString(List<byte[]> p)
        {//Переобразует разбиение в строку
            String result = "";
            foreach (byte[] b in p)
            {
                result += GetString(b);
            }
            return result;
        }

        public static List<byte[]> StringToPartition(String s, long length)
        {/*Разбиваем строку на блоки
          * s - входная строка, length - длина блока в байтах
            */
            List<byte[]> result = new List<byte[]>();
            byte[] bytes = GetBytes(s);
            List<byte> block = new List<byte>();
            int count = 0;
            foreach (byte x in bytes)
            {
                count++;
                if (count < length)
                {
                    block.Add(x);
                }
                else
                {
                    result.Add(block.ToArray());
                    block.Clear();
                    block.Add(x);
                    count = 1;
                }
            }
            if (block.Count > 0) result.Add(block.ToArray());
            return result;
        }


        public static byte[] GetBytes(string str)
        {/*
          * Препобразует строку кодировки windows-1251 в байт-массив 
          * 
            */
            return Encoding.Convert(Encoding.Unicode,
                                     Encoding.GetEncoding("windows-1251"),
                                     Encoding.Unicode.GetBytes(str));
        }

        public static string GetString(byte[] bytes)
        {/*
          * Преобразует байт-массив в строку в кодировке windows-1251
          * */
            var unicodeBytes = Encoding.Convert(
                            Encoding.GetEncoding("windows-1251"), Encoding.Unicode, bytes);
            return Encoding.Unicode.GetString(unicodeBytes);
        }
    }
}
